package com.materialyou.keyboard

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.inputmethodservice.InputMethodService
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.graphics.ColorUtils
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.color.DynamicColors
import com.google.android.material.color.MaterialColors

class KeyboardService : InputMethodService() {

    companion object {
        const val PREFS = "keyboard_prefs"
        private val SYMBOL_ROWS = listOf("1234567890", "@#\$%&-+()/", "=*\"':;!?")
    }

    private enum class Lang(val code: String, val title: String, val rows: List<String>) {
        RU("RU", "Русский", listOf("йцукенгшщзхъ", "фывапролджэ", "ячсмитьбю")),
        EN("EN", "English", listOf("qwertyuiop", "asdfghjkl", "zxcvbnm"))
    }

    private enum class Shift { OFF, ON, CAPS }

    private enum class KeyStyle { LETTER, FUNCTION, SPACE, ENTER }

    private class Key(val root: FrameLayout, val label: TextView?, val icon: ImageView?)

    private class Palette(private val c: Context) {
        private fun col(attr: Int, fallback: Long): Int =
            MaterialColors.getColor(c, attr, fallback.toInt())

        val bg = col(com.google.android.material.R.attr.colorSurfaceContainer, 0xFF2B2930)
        val letter = col(com.google.android.material.R.attr.colorSurfaceContainerHigh, 0xFF36343B)
        val space = col(com.google.android.material.R.attr.colorSurfaceContainerHighest, 0xFF3B383E)
        val function = col(com.google.android.material.R.attr.colorSecondaryContainer, 0xFF4A4458)
        val onFunction = col(com.google.android.material.R.attr.colorOnSecondaryContainer, 0xFFE8DEF8)
        val primary = col(com.google.android.material.R.attr.colorPrimary, 0xFFD0BCFF)
        val onPrimary = col(com.google.android.material.R.attr.colorOnPrimary, 0xFF381E72)
        val pressed = col(com.google.android.material.R.attr.colorPrimaryContainer, 0xFF4F378B)
        val onSurface = col(com.google.android.material.R.attr.colorOnSurface, 0xFFE6E0E9)
        val onSurfaceVariant = col(com.google.android.material.R.attr.colorOnSurfaceVariant, 0xFFCAC4D0)
    }

    private val handler = Handler(Looper.getMainLooper())
    private val prefs: SharedPreferences by lazy { getSharedPreferences(PREFS, MODE_PRIVATE) }
    private val vibrator: Vibrator? by lazy { getSystemService(Vibrator::class.java) }
    private val audio: AudioManager? by lazy { getSystemService(AudioManager::class.java) }
    private val imm: InputMethodManager? by lazy { getSystemService(InputMethodManager::class.java) }

    private var lang = Lang.RU
    private var symbols = false
    private var shift = Shift.OFF
    private var lastShiftTap = 0L

    private var rootView: View? = null
    private var builtSig = ""
    private var palette: Palette? = null
    private var navColor = 0
    private val letterKeys = mutableListOf<Pair<TextView, String>>()
    private var shiftKey: Key? = null

    // ---------------------------------------------------------------- lifecycle

    override fun onCreateInputView(): View {
        val v = buildKeyboard()
        rootView = v
        builtSig = signature()
        return v
    }

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        var needRebuild = rootView == null || builtSig != signature()
        if (!restarting && info != null) {
            val cls = info.inputType and InputType.TYPE_MASK_CLASS
            val wantSymbols = cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE
            if (wantSymbols != symbols) {
                symbols = wantSymbols
                needRebuild = true
            }
        }
        if (needRebuild) rebuild()
        if (shift != Shift.CAPS) shift = Shift.OFF
        autoCapIfNeeded()
        refreshShift()
        applyNavBar()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        handler.removeCallbacksAndMessages(null)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (rootView != null) {
            rebuild()
            applyNavBar()
        }
    }

    private fun signature(): String =
        "${prefs.getBoolean("number_row", true)}|${prefs.getInt("key_height", 48)}"

    private fun rebuild() {
        val v = buildKeyboard()
        rootView = v
        builtSig = signature()
        setInputView(v)
    }

    private fun applyNavBar() {
        try {
            val w = window?.window ?: return
            w.navigationBarColor = navColor
            WindowCompat.getInsetsController(w, w.decorView).isAppearanceLightNavigationBars =
                ColorUtils.calculateLuminance(navColor) > 0.5
        } catch (_: Exception) {
        }
    }

    // ---------------------------------------------------------------- building UI

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    private fun keyBg(normal: Int, pressed: Int): StateListDrawable {
        fun rect(color: Int, radiusDp: Int) = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(radiusDp).toFloat()
            setColor(color)
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), rect(pressed, 22))
            addState(intArrayOf(), rect(normal, 12))
        }
    }

    private fun makeKey(
        c: Context,
        p: Palette,
        style: KeyStyle,
        label: String? = null,
        hint: String? = null,
        icon: Int? = null,
        textSp: Float = 22f
    ): Key {
        val fg = when (style) {
            KeyStyle.LETTER -> p.onSurface
            KeyStyle.FUNCTION -> p.onFunction
            KeyStyle.SPACE -> p.onSurfaceVariant
            KeyStyle.ENTER -> p.onPrimary
        }
        val bg = when (style) {
            KeyStyle.LETTER -> p.letter
            KeyStyle.FUNCTION -> p.function
            KeyStyle.SPACE -> p.space
            KeyStyle.ENTER -> p.primary
        }
        val root = FrameLayout(c)
        root.background = keyBg(bg, p.pressed)

        var lbl: TextView? = null
        var ic: ImageView? = null
        if (label != null) {
            lbl = TextView(c).apply {
                text = label
                setTextColor(fg)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, textSp)
                gravity = Gravity.CENTER
                includeFontPadding = false
            }
            root.addView(lbl, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        if (icon != null) {
            ic = ImageView(c).apply {
                setImageResource(icon)
                setColorFilter(fg)
            }
            root.addView(ic, FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER))
        }
        if (hint != null) {
            val h = TextView(c).apply {
                text = hint
                setTextColor(p.onSurfaceVariant)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
                includeFontPadding = false
            }
            val lp = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.END
            )
            lp.setMargins(0, dp(3), dp(5), 0)
            root.addView(h, lp)
        }
        return Key(root, lbl, ic)
    }

    private fun charKey(c: Context, p: Palette, ch: String, hint: String?, letter: Boolean, alt: String?): Key {
        val k = makeKey(c, p, KeyStyle.LETTER, label = ch, hint = hint)
        if (letter) letterKeys.add(k.label!! to ch)
        val longAction: (() -> Unit)? = if (alt != null) {
            { typeText(if (shift != Shift.OFF) alt.uppercase() else alt) }
        } else null
        attachTouch(
            k.root,
            onLong = longAction,
            onTap = { typeText(if (letter && shift != Shift.OFF) ch.uppercase() else ch) }
        )
        return k
    }

    private fun buildKeyboard(): View {
        val c = DynamicColors.wrapContextIfAvailable(this, R.style.Theme_KeyboardView)
        val p = Palette(c)
        palette = p
        navColor = p.bg
        letterKeys.clear()
        shiftKey = null

        val keyH = dp(prefs.getInt("key_height", 48))
        val numberRow = prefs.getBoolean("number_row", true)
        val rows = if (symbols) SYMBOL_ROWS else lang.rows
        val maxKeys = rows[0].length

        val root = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(p.bg)
            setPadding(dp(4), dp(6), dp(4), dp(6))
        }
        val basePad = dp(6)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val nav = insets.getInsets(WindowInsetsCompat.Type.navigationBars()).bottom
            v.setPadding(dp(4), dp(6), dp(4), basePad + nav)
            insets
        }

        fun newRow(): LinearLayout {
            val r = LinearLayout(c).apply {
                orientation = LinearLayout.HORIZONTAL
                weightSum = maxKeys.toFloat()
            }
            root.addView(r, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, keyH))
            return r
        }

        fun LinearLayout.addKey(k: Key, w: Float) {
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, w)
            lp.setMargins(dp(2), dp(3), dp(2), dp(3))
            addView(k.root, lp)
        }

        fun LinearLayout.addSpacer(w: Float) {
            addView(View(c), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, w))
        }

        // number row
        if (!symbols && numberRow) {
            val r = newRow()
            "1234567890".forEach { d ->
                r.addKey(charKey(c, p, d.toString(), null, false, null), maxKeys / 10f)
            }
        }

        // letter / symbol rows
        rows.forEachIndexed { i, chars ->
            val r = newRow()
            if (i == 2) {
                val rest = maxKeys - chars.length
                if (!symbols) {
                    val sk = makeKey(c, p, KeyStyle.FUNCTION, icon = R.drawable.ic_shift)
                    attachTouch(sk.root, onTap = { onShiftTap() })
                    shiftKey = sk
                    r.addKey(sk, rest / 2f)
                }
                chars.forEach { ch -> r.addKey(rowKey(c, p, ch.toString(), i, chars.indexOf(ch), numberRow), 1f) }
                val bs = makeKey(c, p, KeyStyle.FUNCTION, icon = R.drawable.ic_backspace)
                attachTouch(bs.root, repeat = true, onTap = { backspace() })
                r.addKey(bs, if (symbols) rest.toFloat() else rest / 2f)
            } else {
                val pad = (maxKeys - chars.length) / 2f
                if (pad > 0f) r.addSpacer(pad)
                chars.forEachIndexed { idx, ch -> r.addKey(rowKey(c, p, ch.toString(), i, idx, numberRow), 1f) }
                if (pad > 0f) r.addSpacer(pad)
            }
        }

        // bottom row
        val bottom = newRow()

        val modeKey = makeKey(c, p, KeyStyle.FUNCTION, label = if (symbols) "ABC" else "?123", textSp = 15f)
        attachTouch(modeKey.root, onTap = {
            symbols = !symbols
            rebuild()
        })
        bottom.addKey(modeKey, 1.5f)

        bottom.addKey(charKey(c, p, ",", null, false, null), 1f)

        val langKey = makeKey(c, p, KeyStyle.FUNCTION, label = lang.code, textSp = 15f)
        attachTouch(
            langKey.root,
            onLong = { imm?.showInputMethodPicker() },
            onTap = {
                lang = if (lang == Lang.RU) Lang.EN else Lang.RU
                symbols = false
                rebuild()
            }
        )
        bottom.addKey(langKey, 1f)

        val spaceKey = makeKey(c, p, KeyStyle.SPACE, label = lang.title, textSp = 14f)
        attachTouch(spaceKey.root, onTap = { typeText(" ") })
        bottom.addKey(spaceKey, maxKeys - 6f)

        bottom.addKey(charKey(c, p, ".", null, false, null), 1f)

        val enterKey = makeKey(c, p, KeyStyle.ENTER, icon = R.drawable.ic_enter)
        attachTouch(enterKey.root, onTap = { pressEnter() })
        bottom.addKey(enterKey, 1.5f)

        refreshShift()
        return root
    }

    /** Key for the letter/symbol rows with long-press alternatives. */
    private fun rowKey(c: Context, p: Palette, ch: String, row: Int, index: Int, numberRow: Boolean): Key {
        if (symbols) return charKey(c, p, ch, null, false, null)
        var alt: String? = null
        if (row == 0 && !numberRow && index < 10) alt = "1234567890"[index].toString()
        if (lang == Lang.RU && ch == "е") alt = "ё"
        return charKey(c, p, ch, alt, true, alt)
    }

    // ---------------------------------------------------------------- touch handling

    @SuppressLint("ClickableViewAccessibility")
    private fun attachTouch(
        v: View,
        repeat: Boolean = false,
        onLong: (() -> Unit)? = null,
        onTap: () -> Unit
    ) {
        var longDone = false
        var cancelled = false
        val longRun = object : Runnable {
            override fun run() {
                if (repeat) {
                    onTap()
                    handler.postDelayed(this, 45)
                } else if (onLong != null) {
                    longDone = true
                    feedback()
                    v.isPressed = false
                    onLong()
                }
            }
        }
        v.setOnTouchListener { view, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    longDone = false
                    cancelled = false
                    view.isPressed = true
                    feedback()
                    if (repeat) {
                        onTap()
                        handler.postDelayed(longRun, 400)
                    } else if (onLong != null) {
                        handler.postDelayed(longRun, 380)
                    }
                }
                MotionEvent.ACTION_MOVE -> {
                    val slack = dp(12)
                    if (!cancelled && (ev.x < -slack || ev.x > view.width + slack ||
                                ev.y < -slack || ev.y > view.height + slack)
                    ) {
                        cancelled = true
                        view.isPressed = false
                        handler.removeCallbacks(longRun)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(longRun)
                    view.isPressed = false
                    if (!repeat && !longDone && !cancelled) onTap()
                }
                MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(longRun)
                    view.isPressed = false
                }
            }
            true
        }
    }

    private fun feedback() {
        if (prefs.getBoolean("vibrate", true)) {
            try {
                vibrator?.vibrate(VibrationEffect.createOneShot(16, VibrationEffect.DEFAULT_AMPLITUDE))
            } catch (_: Exception) {
            }
        }
        if (prefs.getBoolean("sound", false)) {
            audio?.playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD, -1f)
        }
    }

    // ---------------------------------------------------------------- input logic

    private fun typeText(s: String) {
        currentInputConnection?.commitText(s, 1)
        afterTyped()
    }

    private fun afterTyped() {
        if (symbols) return
        if (shift == Shift.ON) shift = Shift.OFF
        autoCapIfNeeded()
        refreshShift()
    }

    private fun autoCapIfNeeded() {
        if (shift == Shift.CAPS) return
        if (!prefs.getBoolean("autocap", true)) return
        val ei = currentInputEditorInfo ?: return
        val caps = currentInputConnection?.getCursorCapsMode(ei.inputType) ?: 0
        if (caps != 0) shift = Shift.ON
    }

    private fun backspace() {
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)
        if (!sel.isNullOrEmpty()) {
            ic.commitText("", 1)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        }
        if (!symbols) {
            if (shift != Shift.CAPS) {
                shift = Shift.OFF
                autoCapIfNeeded()
            }
            refreshShift()
        }
    }

    private fun pressEnter() {
        val ic = currentInputConnection ?: return
        val ei = currentInputEditorInfo
        if (ei != null) {
            val action = ei.imeOptions and EditorInfo.IME_MASK_ACTION
            val noEnterAction = (ei.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
            if (!noEnterAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
                ic.performEditorAction(action)
                return
            }
        }
        sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        afterTyped()
    }

    private fun onShiftTap() {
        val now = SystemClock.uptimeMillis()
        shift = when (shift) {
            Shift.OFF -> Shift.ON
            Shift.ON -> if (now - lastShiftTap < 400) Shift.CAPS else Shift.OFF
            Shift.CAPS -> Shift.OFF
        }
        lastShiftTap = now
        refreshShift()
    }

    private fun refreshShift() {
        val p = palette ?: return
        for ((tv, ch) in letterKeys) {
            tv.text = if (shift != Shift.OFF) ch.uppercase() else ch
        }
        val k = shiftKey ?: return
        val active = shift != Shift.OFF
        k.root.background = keyBg(if (active) p.primary else p.function, p.pressed)
        k.icon?.setImageResource(
            when (shift) {
                Shift.OFF -> R.drawable.ic_shift
                Shift.ON -> R.drawable.ic_shift_on
                Shift.CAPS -> R.drawable.ic_caps
            }
        )
        k.icon?.setColorFilter(if (active) p.onPrimary else p.onFunction)
    }
}
