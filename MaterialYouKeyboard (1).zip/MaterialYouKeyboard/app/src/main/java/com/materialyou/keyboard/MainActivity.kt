package com.materialyou.keyboard

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.slider.Slider

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var imm: InputMethodManager
    private lateinit var statusEnable: TextView
    private lateinit var statusDefault: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = getSharedPreferences(KeyboardService.PREFS, MODE_PRIVATE)
        imm = getSystemService(InputMethodManager::class.java)
        statusEnable = findViewById(R.id.status_enable)
        statusDefault = findViewById(R.id.status_default)

        findViewById<android.view.View>(R.id.btn_enable).setOnClickListener {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }
        findViewById<android.view.View>(R.id.btn_select).setOnClickListener {
            if (isEnabled()) {
                imm.showInputMethodPicker()
            } else {
                Toast.makeText(this, "Сначала включите клавиатуру (шаг 1)", Toast.LENGTH_SHORT).show()
            }
        }

        bindSwitch(R.id.sw_vibrate, "vibrate", true)
        bindSwitch(R.id.sw_sound, "sound", false)
        bindSwitch(R.id.sw_numbers, "number_row", true)
        bindSwitch(R.id.sw_autocap, "autocap", true)

        val label = findViewById<TextView>(R.id.height_label)
        val slider = findViewById<Slider>(R.id.slider_height)
        val h = prefs.getInt("key_height", 48).coerceIn(40, 64)
        slider.value = h.toFloat()
        label.text = "Высота клавиш: $h dp"
        slider.addOnChangeListener { _, value, _ ->
            val v = value.toInt()
            prefs.edit().putInt("key_height", v).apply()
            label.text = "Высота клавиш: $v dp"
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) refreshStatus()
    }

    private fun bindSwitch(id: Int, key: String, def: Boolean) {
        val sw = findViewById<MaterialSwitch>(id)
        sw.isChecked = prefs.getBoolean(key, def)
        sw.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(key, checked).apply()
        }
    }

    private fun isEnabled(): Boolean =
        imm.enabledInputMethodList.any { it.packageName == packageName }

    private fun isDefault(): Boolean {
        val current = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
        return current?.startsWith("$packageName/") == true
    }

    private fun refreshStatus() {
        statusEnable.text = if (isEnabled()) "✓ Клавиатура включена" else "Пока не включена"
        statusDefault.text = if (isDefault()) "✓ Используется по умолчанию" else "Сейчас используется другая клавиатура"
    }
}
